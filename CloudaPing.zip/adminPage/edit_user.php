﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>编辑会员资料</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="style/adminStyle.css" rel="stylesheet" type="text/css" />
</head>
<body>
 <div class="wrap">
  <div class="page-title">
    <span class="modular fl"><i class="edit_user"></i><em>编辑会员资料</em></span>
  </div>
  <table class="list-style">
   <tr>
    <td style="width:15%;text-align:right;">会员昵称：</td>
    <td><input type="text" class="textBox length-middle" value="DeathGhost"/></td>
   </tr>
   <tr>
    <td style="text-align:right;">电子邮件：</td>
    <td><input type="text" class="textBox length-middle" value="DeathGhost@sina.cn"/></td>
   </tr>
   <tr>
    <td style="text-align:right;">手机号码：</td>
    <td><input type="text" class="textBox length-middle" value="18309275673"/></td>
   </tr>
   <tr>
    <td style="text-align:right;">可用资金：</td>
    <td>
     <input type="text" class="textBox length-short" value="5000000" disabled="disabled"/>
     <span>元</span>
    </td>
   </tr>
   <tr>
    <td style="text-align:right;">冻结资金：</td>
    <td>
     <input type="text" class="textBox length-short" value="300" disabled="disabled"/>
     <span>元</span>
    </td>
   </tr>
   <tr>
    <td style="text-align:right;">会员等级：</td>
    <td>
     <select class="textBox">
      <option>请选择会员等级</option>
      <option>白金会员</option>
      <option>黄金会员</option>
     </select>
    </td>
   </tr>
   <tr>
    <td style="text-align:right;">重置密码：</td>
    <td><input type="password" class="textBox length-middle" value="123456"/></td>
   </tr>
   <tr>
    <td style="text-align:right;">确认密码：</td>
    <td><input type="password" class="textBox length-middle" value="123456"/></td>
   </tr>
   <tr>
    <td style="text-align:right;"></td>
    <td><input type="submit" class="tdBtn" value="更新保存"/></td>
   </tr>
  </table>
 </div>
</body>
</html>