﻿
<div class="menu-list" style="background:#313131; width: 250px;">
 <a href="admin.php?content=adminPage/main"  class="block menu-list-title center" style="border:none;margin-bottom:8px;color:#fff;">Home</a>
 <ul>
  <li class="menu-list-title">
   <span>Order Management</span>
   <i>◢</i>
  </li>
  <li>
   <ul class="menu-children">
    <li><a href="admin.php?content=adminPage/order/order_list" >Order List</a></li>
   </ul>
  </li>
 
  <li class="menu-list-title">
   <span>Product Management</span>
   <i>◢</i>
  </li>
  <li>
   <ul class="menu-children">
    <li><a href="admin.php?content=adminPage/product/product_list" >Product List</a></li>
    <li><a href="admin.php?content=adminPage/product/recycle_bin" >Old Product</a></li>
   </ul>
  </li>  
  <li class="menu-list-title">
   <span>Advertisement</span>
   <i>◢</i>
  </li>
  <li>
   <ul class="menu-children">
    <li><a href="admin.php?content=adminPage/advertising/advertising_list">Advertising List</a></li>
   </ul>
  </li>
    
 </ul>
</div>
