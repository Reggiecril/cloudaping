﻿
<div class="menu-list" style="background:#313131; width: 250px;">
 <a href="admin.php?content=adminPage/main"  class="block menu-list-title center" style="border:none;margin-bottom:8px;color:#fff;">Home</a>
 <ul>
  <li class="menu-list-title">
   <span>Order Management</span>
   <i>◢</i>
  </li>
  <li>
   <ul class="menu-children">
    <li><a href="admin.php?content=adminPage/order_list" >Order List</a></li>
   </ul>
  </li>
 
  <li class="menu-list-title">
   <span>Product Management</span>
   <i>◢</i>
  </li>
  <li>
   <ul class="menu-children">
    <li><a href="admin.php?content=adminPage/product_list" >Product List</a></li>
    <li><a href="admin.php?content=adminPage/product_category" >Product Category</a></li>
    <li><a href="admin.php?content=adminPage/recycle_bin" >Old Product</a></li>
   </ul>
  </li>

  <li class="menu-list-title">
   <span>系统设置</span>
   <i>◢</i>
  </li>
  <li>
   <ul class="menu-children">
    <li><a href="admin.php?content=adminPage/basic_settings">站点基本设置</a></li>
    <li><a href="admin.php?content=adminPage/admin_list">站点管理员</a></li>
   </ul>
  </li>
  
  <li class="menu-list-title">
   <span>广告管理</span>
   <i>◢</i>
  </li>
  <li>
   <ul class="menu-children">
    <li><a href="admin.php?content=adminPage/advertising_list">广告列表</a></li>
   </ul>
  </li>
    
 </ul>
</div>
