﻿
 <div class="wrap">
  <div class="page-title">
    <span class="modular fl"><i></i><em>Product List</em></span>
    <span class="modular fr"><a href="admin.php?content=adminPage/createProduct/createProductForm" class="pt-link-btn">+Add Product</a></span>
  </div>
  <div class="operate">
   <form>
    <input type="text" class="textBox length-long" placeholder="Enter Product Name..."/>
    <input type="button" value="Search" class="tdBtn"/>
   </form>
  </div>
  <table class="list-style Interlaced">
   <tr>
    <th>ID</th>
    <th>Product</th>
    <th>Type</th>
    <th>Name</th>
    <th>Origin Price</th>
    <th>Now Price</th>
    <th>Quantity</th>
    <th>Recommend</th>
    <th>New</th>
    <th>Popular</th>
    <th>Action</th>
   </tr>
   <?php
        try {

            $dbh = new PDO("mysql:host=$hostname;dbname=$database", $username, $password);
            $result = $dbh->query("SELECT * FROM product WHERE product_trader_id = ".$_SESSION['trader_id']."");
            while($row = $result->fetch()){    

            
    ?>
   <tr>
    <td>
     <span>
     <input type="checkbox" class="middle children-checkbox"/>
     <i><?php echo $row['product_id'];?></i>
     </span>
    </td>
    <td class="center pic-area"><?php print '<img src="assets/images/'.$row['product_mainImage'].'" width="100" height="100" class="mainImage"/>'?></td>
    <td class="center" style="width: 200px">
     <span>
      <em><?php print $row['product_type'] ?></em>
     </span>
    </td>
    <td class="td-name">
      <span class="ellipsis td-name block"><?php print $row['product_name'] ?></span>
    </td>

    <td class="center" style="width: 200px">
     <span>
      <em>GBP<?php print $row['product_originPrice'] ?></em>
     </span>
    </td>
    <td class="center" style="width: 200px">
     <span>
      <em>GBP<?php print $row['product_nowPrice'] ?></em>
     </span>
    </td>
    <td class="center" style="width: 200px">
     <span>
      <em><?php print $row['product_quantity'] ?></em>
     </span>
    </td>
    <?php
    if($row['product_category'] =='recommend'){
      echo '    <td class="center"><img src="assets/images/yes.gif"/></td>
                <td class="center"><img src="assets/images/no.gif"/></td>
                <td class="center"><img src="assets/images/no.gif"/></td>';
    }else if($row['product_category'] =='new'){
      echo '    <td class="center"><img src="assets/images/no.gif"/></td>
                <td class="center"><img src="assets/images/yes.gif"/></td>
                <td class="center"><img src="assets/images/no.gif"/></td>';      
    }else if($row['product_category'] =='popular'){
      echo '    <td class="center"><img src="assets/images/no.gif"/></td>
                <td class="center"><img src="assets/images/no.gif"/></td>
                <td class="center"><img src="assets/images/yes.gif"/></td>';
    }else{
      echo '    <td class="center"><img src="assets/images/no.gif"/></td>
                <td class="center"><img src="assets/images/no.gif"/></td>
                <td class="center"><img src="assets/images/no.gif"/></td>';
    }
    ?>
    <td class="center">
     <a href="admin.php?content=adminPage/createProduct/createProduct" title="Add"><img src="assets/images/icon_edit.gif"/></a>
     <a title="Delete"><img src="assets/images/icon_drop.gif"/></a>
    </td>
   </tr>
   <?php
    }

            }catch(PDOException $e){

                print $e->getMessage();
                die();
            }
                
    ?>
  </table>
  <!-- BatchOperation -->
  <div style="overflow:hidden;">
      <!-- Operation -->
	  <div class="BatchOperation fl">
	   <input type="checkbox" id="del"/>
	   <label for="del" class="btnStyle middle">全选</label>
	   <input type="button" value="批量删除" class="btnStyle"/>
	  </div>
	  <!-- turn page -->
	  <div class="turnPage center fr">
	   <a>Pre</a>
	   <a>1</a>
	   <a>Last</a>
	  </div>
  </div>
 </div>
