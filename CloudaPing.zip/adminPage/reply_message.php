﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>管理员回复</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="style/adminStyle.css" rel="stylesheet" type="text/css" />
<script src="js/jquery.js"></script>
<script src="js/public.js"></script>
</head>
<body>
 <div class="wrap">
  <div class="page-title">
    <span class="modular fl"><i class="user"></i><em>管理员回复</em></span>
  </div>
  <dl>
   <dt class="R-userTitle">DeathGhost:</dt>
   <dd class="R-userCont">这里是用户留言信息哦....</dd>
   <dt class="R-adminTitle">管理员</dt>
   <dd class="R-adminCont">这里是管理员回复信息!这里是管理员回复信息!这里是管理员回复信息!这里是管理员回复信息!这里是管理员回复信息!这里是管理员回复信息!这里是管理员回复信息!这里是管理员回复信息!这里是管理员回复信息!这里是管理员回复信息!这里是管理员回复信息!这里是管理员回复信息!这里是管理员回复信息!这里是管理员回复信息!这里是管理员回复信息!这里是管理员回复信息!这里是管理员回复信息!这里是管理员回复信息!这里是管理员回复信息!</dd>
  </dl>
  <hr/>
  <div>
   <textarea class="textarea block" style="padding:1em;"></textarea>
   <input type="submit" value="回复 " class="tdBtn" style="margin:8px 0;"/>
  </div>
 </div>
</body>
</html>