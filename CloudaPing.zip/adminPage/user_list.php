﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>会员列表</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="style/adminStyle.css" rel="stylesheet" type="text/css" />
<script src="js/jquery.js"></script>
<script src="js/public.js"></script>
</head>
<body>
 <div class="wrap">
  <div class="page-title">
    <span class="modular fl"><i class="user"></i><em>会员列表</em></span>
    <span class="modular fr"><a href="add_user.html" class="pt-link-btn">+添加新会员</a></span>
  </div>
  <div class="operate">
   <form>
    <select class="inline-select">
     <option>选择会员等级</option>
     <option>白金会员</option>
     <option>黄金会员</option>
    </select>
    <input type="text" class="textBox length-long" placeholder="输入会员昵称、姓名、手机号码..."/>
    <input type="button" value="查询" class="tdBtn"/>
   </form>
  </div>
  <table class="list-style Interlaced">
   <tr>
     <th>编号</th>
     <th>会员昵称</th>
     <th>邮件地址</th>
     <th>手机号码</th>
     <th>是否验证</th>
     <th>可用资金</th>
     <th>冻结资金</th>
     <th>注册日期</th>
     <th>操作</th>
   </tr>
   <tr>
    <td>
     <input type="checkbox"/>
     <span class="middle">0</span>
    </td>
    <td class="center">DeathGhost</td>
    <td class="center">DeathGhost@sina.cn</td>
    <td class="center">18309275673</td>
    <td class="center"><img src="images/yes.gif"/></td>
    <td class="center">
     <span>
      <i>￥</i>
      <b>5000000.00</b>
     </span>
    </td>
    <td class="center">
     <span>
      <i>￥</i>
      <b>300.00</b>
     </span>
    </td>
    <td class="center">2015-04-17</td>
    <td class="center">
     <a href="edit_user.html" class="inline-block" title="编辑"><img src="images/icon_edit.gif"/></a>
     <a href="account.html" class="inline-block" title="资金管理"><img src="images/icon_account.gif"/></a>
     <a class="inline-block" title="删除"><img src="images/icon_drop.gif"/></a>
    </td>
   </tr>
   
   <tr>
    <td>
     <input type="checkbox"/>
     <span class="middle">0</span>
    </td>
    <td class="center">DeathGhost</td>
    <td class="center">DeathGhost@sina.cn</td>
    <td class="center">18309275673</td>
    <td class="center"><img src="images/no.gif"/></td>
    <td class="center">
     <span>
      <i>￥</i>
      <b>5000000.00</b>
     </span>
    </td>
    <td class="center">
     <span>
      <i>￥</i>
      <b>300.00</b>
     </span>
    </td>
    <td class="center">2015-04-17</td>
    <td class="center">
     <a href="edit_user.html" class="inline-block" title="编辑"><img src="images/icon_edit.gif"/></a>
     <a href="account.html" class="inline-block" title="资金管理"><img src="images/icon_account.gif"/></a>
     <a class="inline-block" title="删除"><img src="images/icon_drop.gif"/></a>
    </td>
   </tr>
  </table>
  <!-- BatchOperation -->
  <div style="overflow:hidden;">
      <!-- Operation -->
	  <div class="BatchOperation fl">
	   <input type="checkbox" id="del"/>
	   <label for="del" class="btnStyle middle">全选</label>
	   <input type="button" value="批量删除" class="btnStyle"/>
	  </div>
	  <!-- turn page -->
	  <div class="turnPage center fr">
	   <a>第一页</a>
	   <a>1</a>
	   <a>最后一页</a>
	  </div>
  </div>
 </div>
</body>
</html>