<?php
$config['base_url']='localhost';
//Database
$hostname = 'localhost';
$username = 'cloudapi_root';
$password = 'Cloud19961008';
$database = 'cloudapi_root';
$connection = mysqli_connect($hostname, $username, $password, $database) or exit("Unable to connect to database!");
?>