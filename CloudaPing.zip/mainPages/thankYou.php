
<div style="background-color: #eee;height: 700px;">
	<div style="text-align: center;padding: 40px;">
		<img src="assets/images/transpo.png" width="150" height="150">
	</div>
	<div style="padding: 20px;text-align: center;">
		<h1 style="font-size: 80px;">THANK YOU</h1>
	</div>
	<div style="text-align: center;font-size: 30px;margin: 0 auto;width: 1200px;border-bottom: 2px solid #ddd;padding-bottom: 30px;">
		<div style="width: 600px;margin: 0 auto;">
			<p>Check your email shortly for a confirmation of your order. Please keep it for your records.</p>
		</div>
	</div>
	<div style="text-align: center;padding-top: 30px;padding-bottom:10px;font-size: 24px;margin: 0 auto;width: 600px;">
		<p style="display: inline-block;">Having trouble?</p><a href="" style="display: inline-block;" class="btn btn-info">Contact Us</a>
		
	</div>
	<div style="text-align: center;font-size: 20px;margin: 0 auto;width: 600px;">
	<a href="index.php" class="btn btn-primary">Back To Homepage</a>
	</div>
</div>