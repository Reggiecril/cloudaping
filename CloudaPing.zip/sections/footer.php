<footer>
	<div class="footer-product">
		<strong><p>PRODUCT</p></strong>
		<div><a href="index.php?content=mainPages/product&product=laptop">laptop</a></div>
		<div><a href="index.php?content=mainPages/product&product=mobile">mobile</a></div>
		<div><a href="index.php?content=mainPages/product&product=computer">computer</a></div>
		<div><a href="index.php?content=mainPages/product&product=camera">camera</a></div>
		<div><a href="index.php?content=mainPages/product&product=audio&video">audio&video</a></div>
	</div>
	<div class="footer-about-us">
		<strong><p>ABOUT US</p></strong>
		<a href="#">About Us</a>
		</br>
		<a href="#">Contact Us</a>
		</br>
		<a href="#">Feedback</a>
		</br>
	</div>
	<div class="footer-connect">
		<strong><p>CONNECT US</p></strong>
		<a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
		</br>
		<a href="#"><i class="fa fa-facebook-official" aria-hidden="true"></i></a>
		</br>
		<a href="#"><i class="fa fa-google-plus-official" aria-hidden="true"></i></a>
		</br>
		<a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
	</div>
	<div class="footer-download">
		<strong><p>DOWNLOAD</p></strong>
	</div>
</footer>
<div style="text-align: center; color: #aaa; font-size: 14px;">
	<p>©2018 Xie Yuncheng. All rights reserved.</p>
</div>