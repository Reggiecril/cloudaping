<h1 align="center" style="font-size: 60px;">Successed!</h1>
<div class="col-md-2 col-md-offset-4">
	
<img src="assets/images/success.png" alt="success" width="300" height="300" align="center">
</div>